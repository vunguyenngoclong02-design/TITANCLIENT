# TITANCLIENT — Fabric starter

This is a **starter project**, not a finished cheat client. It includes:
- A Fabric client entrypoint named `TITANCLIENT`
- A small module framework with categories and enable/disable state
- Placeholder modules to build on
- Java 21 / Gradle project structure

## Important: verify versions first

Minecraft/Fabric versions change. Before building, open the official Fabric Template Generator:

https://fabricmc.net/develop/template/

Select Minecraft **1.21.11**, Java, and Fabric API. Compare the generated version values with `gradle.properties` and `build.gradle`, then update them if needed. In particular, verify `yarn_mappings`, `loader_version`, `loom_version`, and the Fabric API version.

## Build (GitHub Codespaces or another Java 21 environment)

```bash
chmod +x gradlew
./gradlew build
```

If this archive does not include the Gradle Wrapper scripts, generate them in a Java/Gradle environment with:

```bash
gradle wrapper
```

The output JAR will normally appear in `build/libs/`.

## Source layout

- `TitanClient.java` — client entrypoint
- `ModuleManager.java` — registers and ticks modules
- `modules/Module.java` — module base class
- `modules/Category.java` — module categories

## Next steps

1. Verify dependency versions.
2. Build the empty starter mod.
3. Add a ClickGUI screen and HUD.
4. Implement features in a private test world or with server-owner permission.
