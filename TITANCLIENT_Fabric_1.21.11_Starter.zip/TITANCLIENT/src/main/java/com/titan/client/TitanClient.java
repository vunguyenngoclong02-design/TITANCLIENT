package com.titan.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class TitanClient implements ClientModInitializer {
    public static final String MOD_ID = "titanclient";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("TITANCLIENT initialized.");
        ModuleManager.registerDefaults();

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ModuleManager.tickEnabledModules();
        });
    }
}
