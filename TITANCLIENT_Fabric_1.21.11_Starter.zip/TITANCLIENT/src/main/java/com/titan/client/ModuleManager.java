package com.titan.client;

import com.titan.client.modules.Category;
import com.titan.client.modules.Module;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();

    private ModuleManager() {}

    public static void registerDefaults() {
        if (!MODULES.isEmpty()) return;

        // Safe starter modules: these demonstrate the module framework.
        MODULES.add(new Module("Coordinates HUD", Category.HUD) {});
        MODULES.add(new Module("FPS Display", Category.HUD) {});
        MODULES.add(new Module("Waypoint Notes", Category.WORLD) {});
        MODULES.add(new Module("Crystal PvP Trainer", Category.COMBAT) {});
    }

    public static List<Module> getModules() {
        return Collections.unmodifiableList(MODULES);
    }

    public static void tickEnabledModules() {
        for (Module module : MODULES) {
            if (module.isEnabled()) module.onTick();
        }
    }
}
