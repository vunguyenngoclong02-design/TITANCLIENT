package com.titan.client.modules;

public enum Category {
    COMBAT, RENDER, WORLD, MOVEMENT, MISC, HUD
}
